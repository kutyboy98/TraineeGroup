﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class RoomCore
    {
        public static List<PhongHoc> Get()
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.PhongHocs.ToList();
        }
        public static PhongHoc Get(string roomId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.PhongHocs.Single(x => x.MaPhong.Equals(roomId));
        }
        public static bool Put(PhongHoc room)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.Entry(room).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(PhongHoc room)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.PhongHocs.Add(room);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(string roomId)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                PhongHoc room = db.PhongHocs.Single(x => x.MaPhong.Equals(roomId));
                db.PhongHocs.Remove(room);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}