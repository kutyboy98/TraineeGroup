﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class NewClassCore
    {
        //Lấy danh sách
        public static List<LopMoi> GetAll()
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.LopMois.ToList();
        }
        //Lấy danh sách lớp mới theo năm
        public static List<LopMoi> GetAll(string year)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return (from tb in db.LopMois where tb.NamHoc.Equals(year) select tb).ToList();
        }
            //End
        //Lấy danh sách năm
        public static List<string> Get()
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            var lst = GetAll();
            List<string> result = new List<string>();
            foreach(var item in lst)
            {
                
                if(result.Exists(x=>x.Equals(item.NamHoc))==false)
                {
                    result.Add(item.NamHoc);
                }
            }
            return result;
        }
            //End
        //Lấy danh sách theo năm
        public static List<LopMoi> Get(string date)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return (from tb in db.LopMois where tb.NamHoc.Equals(date) select tb).ToList();
        }
            //End
        //Lấy lớp mới
        public static LopMoi GetFollowId(string newClassId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            int id = Convert.ToInt32(newClassId);
            return db.LopMois.Single(x => x.Ma == id);
        }
        //Lấy danh sách theo trạng thái
        public static List<LopMoi> Get(bool status)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return (from tb in db.LopMois where tb.KetThuc==status select tb).ToList();
        }
            //End
        public static bool Put(LopMoi newClass)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.Entry(newClass).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(LopMoi newClass)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.LopMois.Add(newClass);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(string newClassId)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                int id = Convert.ToInt32(newClassId);
                LopMoi newClass = db.LopMois.Single(x => x.Ma==(id));
                db.LopMois.Remove(newClass);
                db.SaveChanges();
                return true;
            }
            catch(Exception e)
            {
                return false;
            }
        }
    }
}