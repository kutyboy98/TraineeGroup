﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class StudentWithNewClassCore
    {
        //Get
        public static LopMoi_HocSinh Get(string studentId)
        {
            return (from tb in db.LopMoi_HocSinh where tb.MaHocSinh.Equals(studentId) select tb).FirstOrDefault();
        }
        //Sửa 
        public static bool Put(LopMoi_HocSinh item)
        {
            try
            {
                db.Entry(item).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
            //
        //Thêm
        public static bool Post(LopMoi_HocSinh item)
        {
            try
            {
                db.LopMoi_HocSinh.Add(item);                
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        //Xóa
        public static bool Delete(int id)
        {
            try
            {
                LopMoi_HocSinh item = db.LopMoi_HocSinh.Single(x => x.Ma==id);
                db.LopMoi_HocSinh.Remove(item);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        private static dbQLTHPTEntities db = new dbQLTHPTEntities();
    }
}