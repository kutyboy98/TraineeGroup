﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class DivisionCore
    {
        
        public static List<PhanCongGiangDay> Get()
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.PhanCongGiangDays.ToList();
        }
        public static List<PhanCongGiangDay> GetFollowYear(string year)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return (from tb in db.PhanCongGiangDays where tb.LopMoi.NamHoc.Equals(year) select tb).ToList();
        }
        public static PhanCongGiangDay Get(string divisionId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            int id = Convert.ToInt32(divisionId);
            return db.PhanCongGiangDays.Single(x => x.Ma== id);
        }
        public static bool Put(PhanCongGiangDay division)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.Entry(division).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(PhanCongGiangDay division)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.PhanCongGiangDays.Add(division);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(string divisionId)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                int id = Convert.ToInt32(divisionId);
                PhanCongGiangDay division = db.PhanCongGiangDays.Single(x => x.Ma==id);
                db.PhanCongGiangDays.Remove(division);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}