﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class ClassCore
    {
        //Lấy lớp
        public static Lop Get(string classId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.Lops.Single(x => x.Malop == classId);
        }
        //end
        //Lấy lớp
        public static List<Lop> Get()
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.Lops.ToList();
        }
        //end
    }
}