﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class TeacherCore
    {
        public static List<GiaoVien> Get()
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.GiaoViens.ToList();
        }
        public static GiaoVien Get(string teacherId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.GiaoViens.Single(x=>x.MaGV.Equals(teacherId));
        }
        public static List<GiaoVien> GetFollowSubject(string subjectId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return (from gv in db.GiaoViens where gv.MaMon.Equals(subjectId) select gv).ToList();
        }
        public static bool Put(GiaoVien teacher)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.Entry(teacher).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(GiaoVien teacher)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.GiaoViens.Add(teacher);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(string teacherId)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                GiaoVien teacher = db.GiaoViens.Single(x => x.MaGV.Equals(teacherId));
                db.GiaoViens.Remove(teacher);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}