﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class PointCore
    {
        //Lấy danh sách
        public static List<Diem> Get()
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.Diems.ToList();
        }
        //Lấy điểm theo năm hoặc lớp hoặc môn
        public static List<Diem> GetFollowSomething(string year = "0", string classId = "0", string subjectId = "0")
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            try { 
                if(year.Equals("0"))
                {
                    if(classId.Equals("0"))                
                        return (from tb in db.Diems where tb.PhanCongGiangDay.GiaoVien.MaMon.Equals(subjectId) select tb).ToList();                
                    else
                    {
                        if(subjectId.Equals("0"))
                        {
                            return (from tb in db.Diems where tb.PhanCongGiangDay.LopMoi.MaLop.Equals(classId) select tb).ToList();
                        }
                        else
                        {
                            return (from tb in db.Diems where tb.PhanCongGiangDay.GiaoVien.MaMon.Equals(subjectId) && tb.PhanCongGiangDay.LopMoi.MaLop.Equals(classId) select tb).ToList();
                        }
                    }
                        
                }
                else
                {
                    if (classId.Equals("0"))
                    {
                        if(subjectId.Equals("0"))
                            return (from tb in db.Diems where tb.PhanCongGiangDay.LopMoi.NamHoc.Equals(year) select tb).ToList();
                        else
                            return (from tb in db.Diems where tb.PhanCongGiangDay.GiaoVien.MaMon.Equals(subjectId)&& tb.PhanCongGiangDay.LopMoi.NamHoc.Equals(year) select tb).ToList();
                    }                    
                    else
                    {
                        if (subjectId.Equals("0"))
                            return (from tb in db.Diems where tb.PhanCongGiangDay.LopMoi.NamHoc.Equals(year) && tb.PhanCongGiangDay.LopMoi.MaLop.Equals(classId) select tb).ToList();
                        else
                            return (from tb in db.Diems where tb.PhanCongGiangDay.GiaoVien.MaMon.Equals(subjectId) && tb.PhanCongGiangDay.LopMoi.NamHoc.Equals(year) && tb.PhanCongGiangDay.LopMoi.MaLop.Equals(classId) select tb).ToList();
                    }
                }
            }catch(Exception ex) { return null; }
        }
        //Lấy theo Id
        public static Diem Get(int pointId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.Diems.Single(x => x.Ma == pointId);
        }
        //Lấy điểm theo mã học sinh
        public static List<Diem> Get(string studentId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return (from lst in db.Diems where lst.MaHocSinh.Equals(studentId) select lst).ToList();            
        }
        //Sửa
        public static bool Put(Diem point)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                point.DiemTB = (point.DiemMieng + point.Diem15p + point.Diem45p * 2 + point.DiemHocKy * 3) / 7;
                db.Entry(point).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(Diem point)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                point.DiemTB = (point.DiemMieng + point.Diem15p + point.Diem45p * 2 + point.DiemHocKy * 3) / 7;
                db.Diems.Add(point);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(int pointId)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                Diem point = db.Diems.Single(x => x.Ma==pointId);
                db.Diems.Remove(point);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}