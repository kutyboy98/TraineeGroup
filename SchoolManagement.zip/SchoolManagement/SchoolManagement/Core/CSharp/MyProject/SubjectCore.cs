﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class SubjectCore
    {
        public static List<MonHoc> Get()
        {            
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.MonHocs.ToList();
        }
        public static MonHoc Get(string subjectId)
        {
            dbQLTHPTEntities db = new dbQLTHPTEntities();
            return db.MonHocs.Single(x => x.MaMon.Equals(subjectId));
        }
        public static bool Put(MonHoc subject)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.Entry(subject).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(MonHoc subject)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                db.MonHocs.Add(subject);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(string subjectId)
        {
            try
            {
                dbQLTHPTEntities db = new dbQLTHPTEntities();
                MonHoc subject = db.MonHocs.Single(x => x.MaMon.Equals(subjectId));
                db.MonHocs.Remove(subject);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}