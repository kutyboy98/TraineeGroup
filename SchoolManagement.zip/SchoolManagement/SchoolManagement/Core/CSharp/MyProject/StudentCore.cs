﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class StudentCore
    {
        //Lấy danh sách
        public static List<HocSinh> Get(string year="0",string recycle="0")
        {
            dbQLTHPTEntities dbGet = new dbQLTHPTEntities();
            string dateNow;
            if (DateTime.Now.Month < 8)
            {
                dateNow = (DateTime.Now.Year - 1).ToString() + "-" + (DateTime.Now.Year).ToString();
            }
            else
            {
                dateNow = DateTime.Now.Year.ToString() + "-" + (DateTime.Now.Year + 1).ToString();
            }
            if (!year.Equals("0"))
                dateNow = year;
            List<int> newClassId = (from tb in dbGet.LopMois where tb.NamHoc.Equals(dateNow) select tb.Ma).ToList();
            List<HocSinh> resultList = new List<HocSinh>();
            foreach (var item in newClassId)
            {
                resultList.AddRange((from tb in dbGet.LopMoi_HocSinh where tb.MaLopMoi == item select tb.HocSinh).ToList());
            }
            return resultList;
        }
        //Lấy danh sách học sinh theo mã lớp hiện tại
        public static List<HocSinh> GetFollowClass(string classId="0",string year="0")
        {
            try
            {
                dbQLTHPTEntities dbGet = new dbQLTHPTEntities();
                string dateNow;
                if(year.Equals("0"))
                {
                    if (DateTime.Now.Month < 8)
                    {
                        dateNow = (DateTime.Now.Year - 1).ToString() + "-" + (DateTime.Now.Year).ToString();
                    }
                    else
                    {
                        dateNow = DateTime.Now.Year.ToString() + "-" + (DateTime.Now.Year + 1).ToString();
                    }
                    int newClassId = (from tb in dbGet.LopMois where tb.MaLop.Equals(classId) && tb.NamHoc.Equals(dateNow) select tb).FirstOrDefault().Ma;
                    return (from tb in dbGet.LopMoi_HocSinh where tb.MaLopMoi == newClassId select tb.HocSinh).ToList();
                }
                else
                {
                    if(classId.Equals("0"))
                    {
                        return Get(year, "0");
                    }
                    else
                    {
                        int newClassId = (from tb in dbGet.LopMois where tb.MaLop.Equals(classId) && tb.NamHoc.Equals(year) select tb).FirstOrDefault().Ma;
                        return (from tb in dbGet.LopMoi_HocSinh where  tb.MaLopMoi == newClassId select tb.HocSinh).ToList();
                    }
                }
            }
            catch(Exception e)
            {
                return new List<HocSinh>();
            }
        }
        //Lấy theo Id
        public static HocSinh Get(string studentId)
        {
            dbQLTHPTEntities dbGet = new dbQLTHPTEntities();
            return dbGet.HocSinhs.Single(x => x.MaHS == studentId);
        }
        //Sửa
        public static bool Put(HocSinh student)
        {            
            try
            {
                HocSinh std = db.HocSinhs.Single(x => x.MaHS.Equals(student.MaHS));
                std.DiaChi = student.DiaChi;
                std.GioiTinh = student.GioiTinh;
                std.HoTen = student.HoTen;
                std.MaThiTran = student.MaThiTran;
                std.NgaySinh = student.NgaySinh;
                std.Sdt = student.Sdt;
                std.SDTPhuHuynh = student.SDTPhuHuynh;
                std.TenPhuHuynh = student.TenPhuHuynh;                
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        } 
        public static bool Post(HocSinh student)
        {
            try
            {
                db.HocSinhs.Add(student);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(string studentId)
        {
            try
            {
                HocSinh student = StudentCore.Get(studentId);
                foreach (var item in student.LopMoi_HocSinh)
                {
                    StudentWithNewClassCore.Delete(item.Ma);
                }
                foreach (var item in student.Diems)
                {
                    PointCore.Delete(item.Ma);
                }
                dbQLTHPTEntities dbDel = new dbQLTHPTEntities();
                HocSinh studentDel = dbDel.HocSinhs.Single(x => x.MaHS.Equals(studentId));
                dbDel.HocSinhs.Remove(studentDel);
                dbDel.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        private static dbQLTHPTEntities db = new dbQLTHPTEntities();
    }
}