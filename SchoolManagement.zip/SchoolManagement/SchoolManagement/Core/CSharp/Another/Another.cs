﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Core.CSharp
{
    public class Another
    {
        public static DateTime changeDate(DateTime date)
        {
            string[] str = date.ToString("dd/MM/yyy").Split('/');
            return new DateTime(Convert.ToInt32(str[2]),Convert.ToInt32(str[0]),Convert.ToInt32(str[1]));
        }
    }
    
}