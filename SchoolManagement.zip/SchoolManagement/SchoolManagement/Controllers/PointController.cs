﻿using SchoolManagement.Models;
using SchoolManagement.Core.CSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;

namespace SchoolManagement.Controllers
{
    public class PointController : Controller
    {
        // ADD: Point
        public ActionResult addPoint()
        {
            return View();
        }        
        [HttpPost]
        public ActionResult addPoint(Diem Point)
        {
            PointCore.Post(Point);
            return showPoints();
        }
        //End
        //SHOW: Points
        public ActionResult showPoints(string year = "0",string classId = "0",string subjectId = "0")
        {
            if (year.Equals("0"))
            {
                if (Session["year"] == null)
                    Session["year"] = year;
                else
                    year = (string)Session["year"];
            }
            else if(year.Equals("-1"))
            {
                year = "0";
                Session["year"] = year;
            }
            else
            {
                Session["year"] = year;
            }
            if (classId.Equals("0"))
            {
                if (Session["classId"] == null)
                    Session["classId"] = classId;
                else
                    classId = (string)Session["classId"];
            }
            else if (classId.Equals("-1"))
            {
                classId = "0";
                Session["classId"] = classId;
            }
            else
            {
                Session["classId"] = classId;
            }
            if (subjectId.Equals("0"))
            {
                if(Session["subjectId"]==null)
                     Session["subjectId"]= subjectId;
                else
                    subjectId=(string)Session["subjectId"]  ;
            }else if(subjectId.Equals("-1"))
            {
                subjectId = "0";
                Session["subjectId"] = subjectId;
            }
            else
            {
                Session["subjectId"]=subjectId;
            }
            if (year.Equals("0")&&classId.Equals("0")&&subjectId.Equals("0"))
            {
                ViewBag.PointList = PointCore.Get();
            }
            else
            {
                ViewBag.PointList = PointCore.GetFollowSomething(year,classId,subjectId);
            }
            ViewBag.year = year;
            ViewBag.classId = classId;
            ViewBag.subjectId = subjectId;
            ViewBag.classList = ClassCore.Get();
            ViewBag.subjectList = SubjectCore.Get();
            return View();
        }
        //End
        //View: Point
        public ActionResult viewPoint(string PointId)
        {
            int id = Convert.ToInt32(PointId);
            ViewBag.Point = PointCore.Get(id);
            return View();
        }
        //End
        //Edit: Point
        public ActionResult editPoint(string PointId)
        {
            int id = Convert.ToInt32(PointId);
            ViewBag.Point = PointCore.Get(id);
            return View();
        }
        [HttpPost]
        public ActionResult editPoint(Diem Point)
        {
            if (PointCore.Put(Point))
            {
                return RedirectToAction("viewPoint", new { PointId = Point.Ma });
            }
            return RedirectToAction("editPoint", new { PointId = Point.Ma });
        }
        //End
        //Delete: Point
        [HttpPost]
        public JsonResult deletePoint(string PointId)
        {
            int id = Convert.ToInt32(PointId);
            if (PointCore.Delete(id))
            {
                return Json(true);
            }
            return Json(false);
        }
        //End
        //
        public JsonResult getStudentFollowClass(string value,string id)
        {
            List<string> valueList = new List<string>();
            List<string> labelList = new List<string>();
            try
            {
                foreach (var item in NewClassCore.GetFollowId(value).LopMoi_HocSinh)
                {
                        valueList.Add(item.MaHocSinh);
                        labelList.Add(item.HocSinh.HoTen);
                }
            }
            catch { }
            return Json(new { valueList = JsonConvert.SerializeObject(valueList), labelList = JsonConvert.SerializeObject(labelList), id = id });
        }
        public JsonResult getSubjectFollowClass(string newClassId,string studentId, string id)
        {
            List<string> valueList = new List<string>();
            List<string> labelList = new List<string>();
            try
            {
                var Point = PointCore.Get(studentId);
                foreach (var item in NewClassCore.GetFollowId(newClassId).PhanCongGiangDays)
                {
                    try { Point.Single(x => x.MaPCGD == item.Ma); }
                    catch
                    {
                        valueList.Add(item.Ma.ToString());
                        labelList.Add(item.GiaoVien.MonHoc.TenMon);
                    }                    
                }
            }
            catch { }
            return Json(new { valueList = JsonConvert.SerializeObject(valueList), labelList = JsonConvert.SerializeObject(labelList), id = id });
        }
    }
}