﻿using Newtonsoft.Json;
using SchoolManagement.Models;
using SchoolManagement.Core.CSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolManagement.Controllers
{
    public class NewClassController : Controller
    {
        // GET: newClass
        [HttpPost]
        public JsonResult Get(string value,string id)
        {
            List<string> valueList = new List<string>();
            List<string> labelList = new List<string>();
            foreach(var item in NewClassCore.Get(value))
            {
                valueList.Add(item.Ma.ToString());
                labelList.Add(ClassCore.Get(item.MaLop).TenLop);
            }
            return Json(new {valueList = JsonConvert.SerializeObject(valueList),labelList = JsonConvert.SerializeObject(labelList), id = id });
        }
        [HttpPost]
        public JsonResult GetClassNotUse(string value, string id)
        {
            List<string> classList = new List<string>();
            foreach (var item in NewClassCore.Get(value))
            {
                classList.Add(item.MaLop);
            }
            List<string> valueList = new List<string>();
            List<string> labelList = new List<string>();
            foreach(var item in ClassCore.Get())
            {

                try
                {
                    classList.Single(x => x.Equals(item.Malop));
                }
                catch { 
                    valueList.Add(item.Malop);
                    labelList.Add(item.TenLop);
                }
            }
            return Json(new { valueList = JsonConvert.SerializeObject(valueList), labelList = JsonConvert.SerializeObject(labelList), id = id });
        }
        //Lấy danh sách giáo viên ko làm chủ nhiệm năm nào đó
        [HttpPost]
        public JsonResult GetTeacherNotUse(string value, string id)
        {
            List<string> teacherList = new List<string>();
            foreach (var item in NewClassCore.Get(value))
            {
                
                teacherList.Add(item.MaGVChuNhiem);
            }
            List<string> valueList = new List<string>();
            List<string> labelList = new List<string>();
            foreach (var item in TeacherCore.Get())
            {
                try { teacherList.Single(x => x.Equals(item.MaGV)); }
                catch{
                    valueList.Add(item.MaGV);
                    labelList.Add(item.HoTen);
                }
            }
            return Json(new { valueList = JsonConvert.SerializeObject(valueList), labelList = JsonConvert.SerializeObject(labelList), id = id });
        }
        [HttpPost]
        public JsonResult GetRoomNotUse(string value, string id)
        {
            List<string> roomList = new List<string>();
            foreach (var item in NewClassCore.Get(value))
            {                
                roomList.Add(item.MaPhong);
            }
            List<string> valueList = new List<string>();
            List<string> labelList = new List<string>();
            foreach (var item in RoomCore.Get())
            {
                try { roomList.Single(x => x.Equals(item.MaPhong)); }
                catch{
                    valueList.Add(item.MaPhong);
                    labelList.Add("Phòng - "+item.SoPhong);
                }
            }
            return Json(new { valueList = JsonConvert.SerializeObject(valueList), labelList = JsonConvert.SerializeObject(labelList), id = id });
        }
        //end
        // ADD: newClass
        public ActionResult addNewClass()
        {
            ViewBag.teacherList = TeacherCore.Get();
            ViewBag.roomList = RoomCore.Get();
            ViewBag.classList = ClassCore.Get();
            ViewBag.newClassList = NewClassCore.Get(false);
            return View();
        }
        [HttpPost]
        public ActionResult addNewClass(LopMoi newClass)
        {
            NewClassCore.Post(newClass);
            return RedirectToAction("showNewClass", new {year ="0" });
        }
        //End
        //SHOW: newClass
        public ActionResult showNewClass(string year)
        {
            if(year.Equals("0")!=true)
            {
                ViewBag.newClassList = NewClassCore.GetAll(year);
                ViewBag.year = year;
            }
            else
            {
                ViewBag.newClassList = NewClassCore.GetAll();
                ViewBag.year = 0;
            }            
            return View();
        }
        //End
        //View: newClass
        public ActionResult viewNewClass(string newClassId)
        {
            ViewBag.newClass = NewClassCore.GetFollowId(newClassId);
            return View();
        }
        //End
        //Edit: newClass
        public ActionResult editNewClass(string newClassId)
        {
            ViewBag.newClass = NewClassCore.GetFollowId(newClassId);
            ViewBag.teacherList = TeacherCore.Get();
            ViewBag.roomList = RoomCore.Get();
            ViewBag.classList = ClassCore.Get();
            ViewBag.newClassList = NewClassCore.Get(false);
            return View();
        }
        [HttpPost]
        public ActionResult editNewClass(LopMoi newClass)
        {
            if (NewClassCore.Put(newClass))
            {
                return RedirectToAction("viewNewClass", new { newClassId = newClass.Ma });
            }
            return RedirectToAction("editNewClass", new { newClassId = newClass.Ma });
        }
        //End
        //Delete: newClass
        [HttpPost]
        public JsonResult deleteNewClass(string newClassId)
        {
            if (NewClassCore.Delete(newClassId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}