﻿using Newtonsoft.Json;
using SchoolManagement.Core.CSharp;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolManagement.Controllers
{
    public class DivisionController : Controller
    {
        // ADD: Division
        public ActionResult addDivision()
        {                        
            return View();
        }        
        [HttpPost]
        public ActionResult addDivision(PhanCongGiangDay Division)
        {
            DivisionCore.Post(Division);
            return showDivisions();
        }
            //End
        //SHOW: Divisions
        public ActionResult showDivisions(string year="0")
        {
            if (year.Equals("0") != true)
            {
                ViewBag.DivisionList = DivisionCore.GetFollowYear(year);
                ViewBag.year = year;
            }
            else
            {
                ViewBag.DivisionList = DivisionCore.Get();                
                ViewBag.year = 0;
            }            
            return View();
        }
            //End
        //View: Division
        public ActionResult viewDivision(string DivisionId)
        {
            ViewBag.Division = DivisionCore.Get(DivisionId);
            return View();
        }
            //End
        //Edit: Division
        public ActionResult editDivision(string DivisionId)
        {
            ViewBag.Division = DivisionCore.Get(DivisionId);
            return View();
        }
        [HttpPost]
        public ActionResult editDivision(PhanCongGiangDay Division)
        {
            if (DivisionCore.Put(Division))
            {
                return RedirectToAction("viewDivision", new { DivisionId = Division.Ma });
            }
            return RedirectToAction("editDivision", new { DivisionId = Division.Ma });
        }
            //End
        //Delete: Division
        [HttpPost]
        public JsonResult deleteDivision(string DivisionId)
        {
            if (DivisionCore.Delete(DivisionId))
            {
                return Json(true);
            }
            return Json(false);
        }
            //End
        //Lấy danh sách môn học chưa được phân công
        [HttpPost]
        public JsonResult getSubjectNotDeivision(string value, string id)
        {
            List<string> subjectExist = new List<string>();
            foreach (var item in NewClassCore.GetFollowId(value).PhanCongGiangDays)
            {
                subjectExist.Add(item.GiaoVien.MonHoc.MaMon);
            }
            List<string> valueList = new List<string>();
            List<string> labelList = new List<string>();
            try { 
            foreach (var item in SubjectCore.Get())
            {

                try
                {
                    subjectExist.Single(x => x.Equals(item.MaMon));
                }
                catch
                {
                    valueList.Add(item.MaMon);
                    labelList.Add(item.TenMon);
                }
            }
            }
            catch { }
            return Json(new { valueList = JsonConvert.SerializeObject(valueList), labelList = JsonConvert.SerializeObject(labelList), id = id });
        }
        //End
        //Lấy danh sách giáo viên theo mã môn
        [HttpPost]
        public JsonResult getTeacherFollowSubject(string value, string id)
        {
            List<string> valueList = new List<string>();
            List<string> labelList = new List<string>();
            try { 
            foreach (var item in SubjectCore.Get(value).GiaoViens)
            {
                    valueList.Add(item.MaGV);
                    labelList.Add(item.HoTen);
            }
            }
            catch { }
            return Json(new { valueList = JsonConvert.SerializeObject(valueList), labelList = JsonConvert.SerializeObject(labelList), id = id });
        }
    }
}