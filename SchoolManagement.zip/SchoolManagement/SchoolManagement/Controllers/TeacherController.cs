﻿using SchoolManagement.Models;
using SchoolManagement.Core.CSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolManagement.Controllers
{
    public class TeacherController : Controller
    {
        // ADD: Teacher
        public ActionResult addTeacher()
        {
            ViewBag.subjectList = SubjectCore.Get();
            return View();
        }
        [HttpPost]
        public ActionResult addTeacher(GiaoVien teacher)
        {
            TeacherCore.Post(teacher);
            return showTeachers("0");
        }
            //End
        //SHOW: Teachers
        public ActionResult showTeachers(string subjectId)
        {
            if(subjectId.Equals("0"))
            {
                ViewBag.teacherList = TeacherCore.Get();
            }
            else
            {
                ViewBag.teacherList = TeacherCore.GetFollowSubject(subjectId);
            }
            ViewBag.subjectId = subjectId;
            ViewBag.subjectList = SubjectCore.Get();            
            return View();
        }        
            //End
        //View: Teacher
        public ActionResult viewTeacher(string teacherId)
        {
            ViewBag.teacher = TeacherCore.Get(teacherId);
            return View();
        }
            //End
        //Edit: Teacher
        public ActionResult editTeacher(string teacherId)
        {
            ViewBag.subjectList = SubjectCore.Get();
            ViewBag.teacher = TeacherCore.Get(teacherId);            
            return View();
        }
        [HttpPost]
        public ActionResult editTeacher(GiaoVien teacher)
        {
            if (TeacherCore.Put(teacher))
            {
                return RedirectToAction("viewTeacher",new { teacherId=teacher.MaGV });
            }
            return RedirectToAction("editTeacher", new {teacherId=teacher.MaGV });
        }
            //End
        //Delete: Teacher
        [HttpPost]
        public JsonResult deleteTeacher(string teacherId)
        {
            if (TeacherCore.Delete(teacherId))
            {
                return Json(true);
            }
            return Json(false);
        }

    }
}