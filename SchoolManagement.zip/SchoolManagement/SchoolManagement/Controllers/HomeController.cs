﻿using SchoolManagement.Models;
using SchoolManagement.Core.CSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolManagement.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return RedirectToAction("IndexVersion2",new { year="2018-2019"});
        }
        public ActionResult IndexVersion2(string year)
        {
            ViewBag.year = year;
            float[] ratio = new float[12] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            try
            {
                var Pointlst = PointCore.Get();
                var Point10 = from p in Pointlst where p.PhanCongGiangDay.LopMoi.NamHoc.Equals(year) && p.PhanCongGiangDay.LopMoi.Lop.Khoi == 10 select p;
                if(Point10.ToList().Count!=0)
                {
                    ratio[0] = ((from p in Point10 where p.DiemTB < 5 select p).ToList().Count * 100 / Point10.ToList().Count);
                    ratio[3] = ((from p in Point10 where p.DiemTB >= 5 && p.DiemTB < 6 select p).ToList().Count * 100 / Point10.ToList().Count);
                    ratio[6] = ((from p in Point10 where p.DiemTB >= 6 && p.DiemTB < 8 select p).ToList().Count * 100 / Point10.ToList().Count);
                    ratio[9] = ((from p in Point10 where p.DiemTB >= 8 select p).ToList().Count * 100 / Point10.ToList().Count);
                }               
                var Point11 = from p in Pointlst where p.PhanCongGiangDay.LopMoi.NamHoc.Equals(year) && p.PhanCongGiangDay.LopMoi.Lop.Khoi == 11 select p;
                if(Point11.ToList().Count!=0)
                {
                    ratio[1] = ((from p in Point11 where p.DiemTB < 5 select p).ToList().Count * 100 / Point11.ToList().Count);
                    ratio[4] = ((from p in Point11 where p.DiemTB >= 5 && p.DiemTB < 6 select p).ToList().Count * 100 / Point11.ToList().Count);
                    ratio[7] = ((from p in Point11 where p.DiemTB >= 6 && p.DiemTB < 8 select p).ToList().Count * 100 / Point11.ToList().Count);
                    ratio[10] = ((from p in Point11 where p.DiemTB >= 8 select p).ToList().Count * 100 / Point11.ToList().Count);
                }
                var Point12 = from p in Pointlst where p.PhanCongGiangDay.LopMoi.NamHoc.Equals(year) && p.PhanCongGiangDay.LopMoi.Lop.Khoi == 12 select p;                
                if(Point12.ToList().Count!=0)
                {
                    ratio[2] = ((from p in Point12 where p.DiemTB < 5 select p).ToList().Count * 100 / Point12.ToList().Count);
                    ratio[5] = ((from p in Point12 where p.DiemTB >= 5 && p.DiemTB < 6 select p).ToList().Count * 100 / Point12.ToList().Count);
                    ratio[8] = ((from p in Point12 where p.DiemTB >= 6 && p.DiemTB < 8 select p).ToList().Count * 100 / Point12.ToList().Count);
                    ratio[11] = ((from p in Point12 where p.DiemTB >= 8 select p).ToList().Count * 100 / Point12.ToList().Count);
                }                
                ViewBag.ratio = ratio;
            }
            catch
            {
                ViewBag.ratio = ratio;
            }
            return View("Index");
        }


    }
}