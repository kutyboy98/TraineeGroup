﻿using SchoolManagement.Core.CSharp;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolManagement.Controllers
{
    public class StudentController : Controller
    {
        // ADD: Student
        public ActionResult addStudent()
        {
            ViewBag.yearList = NewClassCore.Get(); 
            return View();
        }
        [HttpPost]
        public ActionResult addStudent(HocSinh student,string newClassId)
        {
            StudentCore.Post(student);
            StudentWithNewClassCore.Post(new LopMoi_HocSinh { MaHocSinh = student.MaHS, MaLopMoi = Convert.ToInt32(newClassId),ThoiGian=DateTime.Now });
            return RedirectToAction("showStudents",new {classId = "0"});
        }
            //End
        //SHOW: Students
        public ActionResult showStudents(string classId="0",string year="0")
        {
            if (year.Equals("0"))
            {
                if (Session["year"] == null)
                    Session["year"] = year;
                else
                    year = (string)Session["year"];
            }
            else if (year.Equals("-1"))
            {
                year = "0";
                Session["year"] = year;
            }
            else
            {
                Session["year"] = year;
            }
            if (classId.Equals("0"))
            {
                if (Session["classId"] == null)
                    Session["classId"] = classId;
                else
                    classId = (string)Session["classId"];
            }
            else if (classId.Equals("-1"))
            {
                classId = "0";
                Session["classId"] = classId;
            }
            else
            {
                Session["classId"] = classId;
            }
            if (classId.Equals("0")&&year.Equals("0"))
            {
                ViewBag.studentList = StudentCore.Get("0","0");
            }
            else
            {
                ViewBag.studentList = StudentCore.GetFollowClass(classId,year);
            }
            ViewBag.classId = classId;
            ViewBag.year = year;
            ViewBag.classList = ClassCore.Get();            
            return View();
        }
            //End
        //View: Student
        public ActionResult viewStudent(string studentId)
        {
            ViewBag.student = StudentCore.Get(studentId);
            return View();
        }
            //End
        //Edit: Student
        public ActionResult editStudent(string studentId)
        {
            ViewBag.student = StudentCore.Get(studentId);
            ViewBag.yearList = NewClassCore.Get();
            return View();
        }
        [HttpPost]
        public ActionResult editStudent(HocSinh student, string newClassId)
        {
            if(StudentCore.Put(student))
            {
                foreach(var item in StudentCore.Get(student.MaHS).LopMoi_HocSinh)
                {
                    if(item.MaLopMoi== Convert.ToInt32(newClassId))
                        return RedirectToAction("viewStudent", new { studentId = student.MaHS });
                }                
                    StudentWithNewClassCore.Post(new LopMoi_HocSinh { MaHocSinh = student.MaHS, MaLopMoi = Convert.ToInt32(newClassId),ThoiGian=DateTime.Now });
                return RedirectToAction("viewStudent", new { studentId = student.MaHS });
            }
            return editStudent(student.MaHS);
        }
            //End
        //Delete: Student
        [HttpPost]
        public JsonResult deleteStudent(string StudentId)
        {            
            if(StudentCore.Delete(StudentId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}