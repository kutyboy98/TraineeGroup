﻿(function (app) {
    app.controller('borrowRoomListController', function ($scope, $http, $state, request, service) {
        $scope.BorrowRooms = [];
        $scope.confirm = function(text,Id)
        {
            service.confirm_ajax(text, $scope.delete, Id);
        }
        $scope.delete = function (RoomId) {
            request.post("/BorrowRoom/deleteBorrowRoom?BorrowRoomId=" + RoomId, null, function (response) {
                if (response.data==true) {
                    service.confirm_basic("Xóa thành công!");
                    $state.reload();
                }
                else
                    service.confirm_basic("Xóa thất bại!");
            }, function (response) {
                    service.confirm_basic("Xóa thất bại!");
            });
        }                  
        function init() {
            service.load_theme_start();
            $scope.pageSize = 10;
            request.get("/BorrowRoom/showBorrowRooms", null, function (response) {
                //response.data = JSON.parse(response.data);                                               
                    $scope.BorrowRooms = response.data.data;                
            }, function (response) { });
            service.load_theme_end();
        }
        init();
                      
        
    });
})(angular.module('JkerApp'));