﻿(function (app) {
    app.controller('borrowRoomAddController', function ($scope, $http, $state, request, service) {
        $scope.o = {};
        $scope.p={};
        $scope.rooms = [];
        $scope.customers = [];
        $scope.employees = [];
        $scope.datas = [];
        $scope.choice_room = function()
        {
            $scope.p.Title = "Phòng";
            $scope.datas = $scope.rooms;
        }
        $scope.choice_customer = function()
        {
            $scope.p.Title = "Khách hàng";
            $scope.datas = $scope.customers;
        }
        $scope.choice_employee = function()
        {
            $scope.p.Title = "Nhân viên";
            $scope.datas = $scope.employees;
        }
        $scope.confirm = function(name,id,index)
        {
            if(index==1)
            {
                $scope.p.Room = name;
                $scope.o.Room = id;
            }
            if (index == 2) {
                $scope.p.Customer = name;
                $scope.o.Customer = id;
            }
            if (index == 3) {
                $scope.p.Employee = name;
                $scope.o.Employee = id;
            }
        }
        $scope.add = function()
        {
            service.load_theme_start();
            request.post("/BorrowRoom/addBorrowRoom", $scope.o, function (response) {
                if(response.data.status)
                    service.pnotify(response.data.mess, "", 'success');
                else
                    service.pnotify(response.data.mess, "", 'error');
            }, function (response) { });
            service.load_theme_end();
        }
        $scope.change_date = function()
        {
            if ($scope.o.ComeDay > $scope.o.ReturnDay)
            {
                service.pnotify("Ngày trả phỏng cần lớn hơn ngày đến!", "", 'error');
                return;
            }
            if ($scope.o.ReturnDay == null || $scope.o.ComeDay == null)
                return;
            var date = ((new Date().getMonth() + 1) < 10 ? "0" + (new Date().getMonth() + 1) : (new Date().getMonth() + 1))+ "/" + ((new Date().getDate()) < 10 ? "0"+new Date().getDate() : new Date().getDate()) + "/" + (new Date().getFullYear());
            if ($scope.o.ComeDay >= date && $scope.o.ReturnDay != null)
            {
                request.get("/Room/showRoomsDate?ComeDay="+$scope.o.ComeDay+"&ReturnDay="+$scope.o.ReturnDay, null, function (response) {
                    $scope.rooms.length = 0;
                    for (var i = 0; i < response.data.data.length; i++) {
                        $scope.rooms.push({ 'Name': 'Phòng số ' + response.data.data[i].Number + ' - tầng ' + response.data.data[i].Floor + ' - loại ' + response.data.data[i].tbLoaiPhong.Name, 'Id': response.data.data[i].Id, 'Index': 1 });
                    }
                }, function (response) { });
            }            
        }
        function init() {
            service.load_theme_start();
            request.get("/Room/showRoomsStatus?status=true", null, function (response) {
                for(var i =0; i<response.data.data.length;i++)
                {
                    $scope.rooms.push({ 'Name': 'Phòng số ' + response.data.data[i].Number + ' - tầng ' + response.data.data[i].Floor +' - loại ' + response.data.data[i].tbLoaiPhong.Name, 'Id': response.data.data[i].Id, 'Index': 1 });
                }                
            }, function (response) { });
            request.get("/Customer/showCustomers", null, function (response) {
                for (var i = 0; i < response.data.data.length; i++) {
                    $scope.customers.push({ 'Name': response.data.data[i].Name, 'Id': response.data.data[i].Id, 'Index': 2 });
                }
            }, function (response) { });
            request.get("/Employee/showEmployees", null, function (response) {
                for (var i = 0; i < response.data.data.length; i++) {
                    $scope.employees.push({ 'Name': response.data.data[i].Name, 'Id': response.data.data[i].Id, 'Index': 3 });
                }
            }, function (response) { });
            service.date_dropper('animation', "create_day");
            service.date_dropper('animation', "come_day");
            service.date_dropper('animation', "return_day");
            $scope.pageSize = 10;
            service.load_theme_end();
        }
        init();
    });
})(angular.module('JkerApp'));