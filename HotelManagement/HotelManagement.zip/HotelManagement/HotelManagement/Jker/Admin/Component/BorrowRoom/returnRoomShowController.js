﻿(function (app) {
    app.controller('returnRoomShowController', function ($scope, $http, $stateParams, $state, request, service) {
        $scope.o = {};        
        $scope.print = function(id)
        {
            service.to_pdf(id);
        }
        function init() {
            service.load_theme_start();
            request.get("/BorrowRoom/viewReturnRoom?BorrowRoomId=" + $stateParams.ID, null, function (response) {
                $scope.o = response.data.data;
                $scope.o.tbKhachHang.Card = $scope.o.tbKhachHang.Card.substring(0, 4) + '*****';
                $scope.o.ServiceTotalPrice = 0;
                for(var i =0 ;i< response.data.data.tbPhieuDichVus.length;i++)
                {
                    $scope.o.ServiceTotalPrice += response.data.data.tbPhieuDichVus[i].TotalPrice;
                }
            }, function (response) { });                       
            service.load_theme_end();
        }
        init();
    });
})(angular.module('JkerApp'));