﻿(function (app) {
    app.controller('employeeListController', function ($scope, $http, $state, request, service) {
        $scope.Employees = [];
        $scope.confirm = function(text,Id)
        {
            service.confirm_ajax(text, $scope.delete, Id);
        }
        $scope.delete = function (RoomId) {
            request.post("/Employee/deleteEmployee?EmployeeId=" + RoomId, null, function (response) {
                if (response.data==true) {
                    service.confirm_basic("Xóa thành công!");
                    $state.reload();
                }
                else
                    service.confirm_basic("Xóa thất bại!");
            }, function (response) {
                    service.confirm_basic("Xóa thất bại!");
            });
        }        
        async function init() {
            service.load_theme_start();
            $scope.pageSize = 10;
            await request.get("/Employee/showEmployees", null, function (response) {
                //response.data = JSON.parse(response.data);                                               
                    $scope.Employees = response.data.data;                
            }, function (response) { });            
            service.load_theme_end();
        }
        init();
                      
        
    });
})(angular.module('JkerApp'));