﻿(function (app) {
    app.controller('employeeAddController', function ($scope, $http, $state, request, service) {
        $scope.o = {};
        $scope.city;
        $scope.district;
        $scope.city_list = {};
        $scope.town_list = {};
        $scope.add = function()
        {
            service.load_theme_start();
            request.post("/Employee/addEmployee", $scope.o, function (response) {
                if (response.data.status)
                {
                    service.load_theme_end();
                    service.pnotify(response.data.mess, "", 'success');
                    $state.go("employeeListView");
                }                    
                else
                    service.pnotify(response.data.mess, "", 'error');
            }, function (response) { });
            service.load_theme_end();
        }
        $scope.get_district = function () {
            request.get("/Address/getDistrictList?cityId=" + $scope.city, null, function (response) {
                $scope.district_list = response.data.data;
            }, function () { });
        }
        $scope.get_town = function () {
            request.get("/Address/getTownList?districtId=" + $scope.district, null, function (response) {
                $scope.town_list = response.data.data;
            }, function () { });
        }
        function init() {
            service.load_theme_start();
            $scope.o.Gender = 'Nam';
            service.date_dropper('animation', "date");
            request.get("/Address/getCityList", null, function (response) {
                $scope.city_list = response.data.data;
            }, function () { });
            service.load_theme_end();
        }
        init();
    });
})(angular.module('JkerApp'));