﻿(function (app) {
    app.controller('employeeEditController', function ($scope, $stateParams, $http, $state, request, service) {
        $scope.o = {};
        $scope.city;
        $scope.district;
        $scope.city_list = {};
        $scope.town_list = {};
        $scope.edit = function()
        {
            service.load_theme_start();
            request.post("/Employee/editEmployee", $scope.o, function (response) {
                if(response.data.status)
                {
                    service.pnotify(response.data.mess, "", 'success');
                    service.load_theme_start();
                    $state.go('employeeListView');
                }                                   
                else
                    service.pnotify(response.data.mess, "", 'error');
            }, function (response) { });
            service.load_theme_start();
        }
        $scope.get_district = function () {
            request.get("/Address/getDistrictList?cityId=" + $scope.city, null, function (response) {
                $scope.district_list = response.data.data;
            }, function () { });
        }
        $scope.get_town = function () {
            request.get("/Address/getTownList?districtId=" + $scope.district, null, function (response) {
                $scope.town_list = response.data.data;
            }, function () { });
        }
        function init() {
            service.load_theme_start();
            service.date_dropper('animation', "date");
            request.get("/Employee/viewEmployee?EmployeeId=" + $stateParams.ID, null, function (response) {
                $scope.o = response.data.data;
            }, function (response) { });            
            request.get("/Address/getCityList", null, function (response) {
                $scope.city_list = response.data.data;
                request.get("/Address/getAddress?townId=" + $scope.o.Town, null, function (response) {
                    $scope.city = response.data.data.cityId;
                    $scope.district = response.data.data.districtId;
                    $scope.get_district();
                    $scope.get_town();
                }, function () { });
            }, function () { });          
            service.load_theme_end();
        }
        init();
    });
})(angular.module('JkerApp'));