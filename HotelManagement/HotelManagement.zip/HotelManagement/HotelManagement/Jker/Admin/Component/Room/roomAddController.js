﻿(function (app) {
    app.controller('roomAddController', function ($scope, $http, $state, request, service) {
        $scope.o = {};
        $scope.RoomCategorys = {};
        $scope.add = function()
        {
            request.post("/Room/addRoom", $scope.o, function (response) {
                if(response.data.status)
                    service.pnotify(response.data.mess, "", 'success');
                else
                    service.pnotify(response.data.mess, "", 'error');
            }, function (response) { });
        }
        function init() {
            request.get("/RoomCategory/showRoomCategorys", null, function (response) {
                $scope.RoomCategorys = response.data.data;
            }, function (response) { });
        }
        init();
    });
})(angular.module('JkerApp'));