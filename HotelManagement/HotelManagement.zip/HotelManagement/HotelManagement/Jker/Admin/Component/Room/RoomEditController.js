﻿(function (app) {
    app.controller('roomEditController', function ($scope, $stateParams, $http, $state, request, service) {
        $scope.o = {};
        $scope.RoomCategorys = {};
        $scope.edit = function()
        {
            request.post("/Room/editRoom", $scope.o, function (response) {
                if(response.data.status)
                {
                    service.pnotify(response.data.mess, "", 'success');     
                    $state.go('roomListView');
                }                                   
                else
                    service.pnotify(response.data.mess, "", 'error');
            }, function (response) { });
        }
        function init() {            
            request.get("/RoomCategory/showRoomCategorys", null, function (response) {
                $scope.RoomCategorys = response.data.data;
                request.get("/Room/viewRoom?RoomId=" + $stateParams.ID, null, function (response) {
                    $scope.o = response.data.data;
                    $scope.o.Category = response.data.data.Category;
                }, function (response) { });
            }, function (response) { });            
        }
        init();
    });
})(angular.module('JkerApp'));