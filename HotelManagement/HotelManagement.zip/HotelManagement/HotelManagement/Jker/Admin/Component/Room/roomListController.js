﻿(function (app) {
    app.controller('roomListController', function ($scope, $http, $state, request, service) {
        $scope.Rooms = [];
        $scope.confirm = function(text,Id)
        {
            service.confirm_ajax(text, $scope.delete, Id);
        }
        $scope.delete = function (RoomId) {
            request.post("/Room/deleteRoom?RoomId="+RoomId,null, function (response) {
                if (response.data==true) {
                    service.confirm_basic("Xóa thành công!");
                    $state.reload();
                }
                else
                    service.confirm_basic("Xóa thất bại!");
            }, function (response) {
                    service.confirm_basic("Xóa thất bại!");
            });
        }                  
        function init() {
            request.get("/Room/showRooms", null, function (response) {
                //response.data = JSON.parse(response.data);
                $scope.Rooms = response.data.data;
                //var html = '';
                //var Template = $("#room-template").html();
                //$.each(response.data.data, function (index, elm) {
                //    html += Mustache.render(Template, {
                //        Number: elm.Number,
                //        Floor: elm.Floor,
                //        Desciption: elm.tbLoaiPhong.Description,
                //        Category: elm.tbLoaiPhong.Name,
                //        Id: elm.Id,
                //        Class: elm.Status
                //    });
                //});
                //$("#book-container").append(html);
            }, function (response) { });
        }
        init();
                      
        
    });
})(angular.module('JkerApp'));