﻿(function (app) {
    app.controller('HomeInfoController', function ($scope, $http, $state, request,service) {                
        function Init()
        {                        
            // Start theme 
            service.load_theme_start();
            // Get bar chart
            service.bar_chart('barChart');
            // Get Account
            request.get("/Account/viewAccount", null, function (response) {
                // Call notify
                service.pnotify('Xin chào '+ response.data.data.accountName,'', 'default');                
            }, function () { });                        
            // Finnish theme
            service.load_theme_end();
        }
        //Run init
        Init();
        });        
})(angular.module('JkerApp'));