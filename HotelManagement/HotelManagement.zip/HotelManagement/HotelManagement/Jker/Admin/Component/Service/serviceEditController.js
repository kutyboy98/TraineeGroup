﻿(function (app) {
    app.controller('serviceEditController', function ($scope,$stateParams, $http, $state, request, service) {
        $scope.o = {};
        $scope.o.tbCT_PhieuDichVu = [];
        $scope.datas = [];
        $scope.BorrowRooms = [];
        $scope.confirm = function(v)
        {
            //$scope.o.tbCT_PhieuDichVu.push({ 'Service': v.Id, 'Amount': 1, 'Name': v.Name , 'Price': v.Price });
            $scope.o.tbCT_PhieuDichVu.push({ 'Service': v.Id,'ServiceTicket':$scope.o.Id, 'Amount': 1, 'tbDichVu':{'Name': v.Name}, 'Price': v.Price });
            //$scope.p.push({ 'Service': $scope.datas[index].Id, 'Amount': 1, 'Name': $scope.datas[index].Name, 'Price': $scope.datas[index].Price });
        }
        $scope.cancel = function (index) {
            $scope.o.tbCT_PhieuDichVu.splice(index, 1);
        }
        $scope.edit = function()
        {
            service.load_theme_start();            
            request.post("/Service/editService", $scope.o, function (response) {
                if(response.data.status)
                {
                    service.load_theme_end();
                    service.pnotify(response.data.mess, "", 'success');
                    $state.go('serviceListView');
                }                    
                else
                    service.pnotify(response.data.mess, "", 'error');
            }, function (response) { });
            service.load_theme_end();
        }
        function init() {
            service.load_theme_start();
            request.get("/Service/viewService?ServiceId=" + $stateParams.ID, null, function (response) {
                $scope.o = response.data.data;                
                $scope.o.tbCT_PhieuDichVu = response.data.data.tbCT_PhieuDichVu;
                request.get("/BorrowRoom/showBorrowRooms", null, function (response) {
                    for(var i =0 ;i<response.data.data.length;i++)
                    {
                        $scope.BorrowRooms.push({ 'Id': response.data.data[i].Id, 'label': "Phòng " + response.data.data[i].tbPhong.Number + " - Tầng " + response.data.data[i].tbPhong.Floor + " - Loại " + response.data.data[i].tbPhong.tbLoaiPhong.Name });
                    }                    
                }, function (response) { });
            }, function (response) { });            
            request.get("/Item/showItems", null, function (response) {
                $scope.datas = response.data.data;
            }, function (response) { });
            
            $scope.pageSize = 10;
            service.load_theme_end();
        }
        init();
    });
})(angular.module('JkerApp'));