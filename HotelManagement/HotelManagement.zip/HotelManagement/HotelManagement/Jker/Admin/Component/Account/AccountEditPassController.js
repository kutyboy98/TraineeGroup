﻿(function (app) {
    app.controller('AccountEditPassCtrl', function ($scope, $http, $state, request, service) {
        $scope.p = {};
        $scope.edit_pass = function()
        {
            service.load_theme_start();
            request.post("/Account/changePass", $scope.p, function (response) {
                response.data = JSON.parse(response.data);
                if(response.data.status)
                    service.pnotify(response.data.mess,'','success');
                else
                    service.pnotify(response.data.mess, '', 'error');
            }, function (response) {
                response.data = JSON.parse(response.data);
                service.pnotify(response.data.mess, '', 'error');
            });
            service.load_theme_end();
        }
        $scope.check_old_pass = function()
        {
            request.post("/Account/checkOldPass", $scope.p, function (response) {
                response.data = JSON.parse(response.data);
                if (response.data.status)
                   service.pnotify(response.data.mess, '', 'success');
                else
                    service.pnotify(response.data.mess, '', 'error');
            }, function (response) {
                response.data = JSON.parse(response.data);
                service.pnotify(response.data.mess, '', 'error');
            });
        }
        $scope.check_new_pass = function () {
            if($scope.p.NewPass!=$scope.p.NewPassAgain)
            {
                //service.pnotify('Mật khẩu ko khớp!', '', 'error');
            }
            else
            {
                service.pnotify('Mật khẩu mới khớp!', '', 'success');
            }
        }
        function init()
        {
            $scope.OldPass = '';
        }
        init();
    });
})(angular.module('JkerApp'));