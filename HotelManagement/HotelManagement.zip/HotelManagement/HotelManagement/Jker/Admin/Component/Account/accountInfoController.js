﻿(function (app) {
    app.controller('AccountInfoCtrl', function ($scope, $http, $state, request,service) {
        $scope.account = {};
        $scope.city;
        $scope.district;
        $scope.city_list = {};        
        $scope.town_list = {};
        //Edit profile
        $scope.edit_profile = function()
        {
            service.load_theme_start();
            var b = $('#edit-btn').find("i");
                var edit_class = b.attr('class');
                if (edit_class == 'icofont icofont-edit') {
                    b.removeClass('icofont-edit');
                    b.addClass('icofont-close');
                    $('.view-info').hide();
                    $('.edit-info').show();
                } else {
                    b.removeClass('icofont-close');
                    b.addClass('icofont-edit');
                    $('.view-info').show();
                    $('.edit-info').hide();
                }
                service.load_theme_end();
        }
        //Edit account
        $scope.edit_account = function () {
            service.load_theme_start();
            // Set image 
            $scope.account.accountImage = $('#ip-img').val();
            //Call action editAccount from Account Controller
            request.post("/Account/editAccount", $scope.account, function (response) {
                response.data = JSON.parse(response.data);
                if(response.data.status)
                {
                    service.pnotify(response.data.mess,'','success');
                }
                else
                {
                    service.pnotify( response.data.mess, '','error');
                }
                service.load_theme_end();
                $state.reload();
            }, function () {
                service.pnotify('error', response.data.mess, '');
                service.load_theme_end();
            });
        }
        $scope.get_district = function () {
            request.get("/Address/getDistrictList?cityId="+$scope.city,null, function (response) {
                $scope.district_list = response.data.data;
            }, function () { });
        }
        $scope.get_town = function () {
            request.get("/Address/getTownList?districtId="+ $scope.district,null, function (response) {
                $scope.town_list = response.data.data;
            }, function () { });
        }
        $scope.change_image = function()
        {
            // Set Ckfinder
            service.Ckfinder('src-img', 'ip-img');            
        }
        $scope.change_gender = function (value) {
            $scope.account.accountSex = value;
        }        
        function Init()
        {            
            // Start date dropper
            service.date_dropper('animation', "date");
            // Start theme 
            service.load_theme_start();
            // Get Account
            request.get("/Account/viewAccount", null, function (response) {
                // Set account
                $scope.account = response.data.data;                                
                //Get str address
                request.get("/Address/getStrAddress?townId=" + $scope.account.accountTown, null, function (response) {
                    $scope.strAddress = response.data.data;
                }, function () { });
            }, function () { });
            // Get City
            request.get("/Address/getCityList", null, function (response) {
                $scope.city_list = response.data.data;
            }, function () { });            
            // Finnish theme
            service.load_theme_end();
        }
        //Run init
        Init();
        });        
})(angular.module('JkerApp'));