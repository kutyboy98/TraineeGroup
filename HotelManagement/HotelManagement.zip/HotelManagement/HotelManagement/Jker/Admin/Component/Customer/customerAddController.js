﻿(function (app) {
    app.controller('customerAddController', function ($scope, $http, $state, request, service) {
        $scope.o = {};
        $scope.RoomCategorys = {};
        $scope.add = function()
        {
            service.load_theme_start();
            request.post("/Customer/addCustomer", $scope.o, function (response) {
                if(response.data.status)
                {
                    service.load_theme_end();
                    service.pnotify(response.data.mess, "", 'success');
                    $state.go('customerListView');
                }                
                else
                    service.pnotify(response.data.mess, "", 'error');
            }, function (response) { });
            service.load_theme_end();
        }
        function init() {
            service.load_theme_start();
            $scope.o.Gender = 'Nam';
            service.load_theme_end();
        }
        init();
    });
})(angular.module('JkerApp'));