﻿(function (app) {
    app.controller('customerEditController', function ($scope, $stateParams, $http, $state, request, service) {
        $scope.o = {};
        $scope.RoomCategorys = {};
        $scope.edit = function()
        {
            service.load_theme_start();
            request.post("/Customer/editCustomer", $scope.o, function (response) {
                if(response.data.status)
                {
                    service.load_theme_end();
                    service.pnotify(response.data.mess, "", 'success');     
                    $state.go('customerListView');
                }                                   
                else
                    service.pnotify(response.data.mess, "", 'error');
            }, function (response) { });
            service.load_theme_end();
        }
        function init() {
            service.load_theme_start();
            request.get("/Customer/viewCustomer?CustomerId=" + $stateParams.ID, null, function (response) {
                $scope.o = response.data.data;
            }, function (response) { });
            service.load_theme_end();
        }
        init();
    });
})(angular.module('JkerApp'));