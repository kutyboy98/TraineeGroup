﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class RoomCategoryDao
    {
        public static List<tbLoaiPhong> Get()
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbLoaiPhongs.ToList();
        }
        public static tbLoaiPhong Get(string RoomCategoryId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbLoaiPhongs.Single(x => x.Id.Equals(RoomCategoryId));
        }
        public static bool Put(tbLoaiPhong RoomCategory)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.Entry(RoomCategory).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(tbLoaiPhong RoomCategory)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbLoaiPhongs.Add(RoomCategory);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(string RoomCategoryId)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                tbLoaiPhong RoomCategory = db.tbLoaiPhongs.Single(x => x.Id.Equals(RoomCategoryId));
                db.tbLoaiPhongs.Remove(RoomCategory);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}