﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class BillDao
    {
        public static bool Post(tbHoaDon Bill)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbHoaDons.Add(Bill);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}