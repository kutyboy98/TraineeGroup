﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class ServiceDao
    {
        public static List<tbPhieuDichVu> Get()
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbPhieuDichVus.ToList();
        }
        public static tbPhieuDichVu Get(int ServiceId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbPhieuDichVus.Single(x => x.Id == ServiceId);
        }
        public static bool Put(tbPhieuDichVu Service)
        {
            try
            {
                Service.tbCT_PhieuDichVu = null;
                Service.tbPhieuDatPhong = null;
                dbQLKhachSan db = new dbQLKhachSan();
                db.Entry(Service).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(tbPhieuDichVu Service)
        {            
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbPhieuDichVus.Add(Service);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(int ServiceId)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                tbPhieuDichVu Service = db.tbPhieuDichVus.Single(x => x.Id == ServiceId);
                db.tbPhieuDichVus.Remove(Service);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }

        }
    }
}