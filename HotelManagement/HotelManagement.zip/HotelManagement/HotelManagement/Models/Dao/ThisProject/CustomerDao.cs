﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class CustomerDao
    {
        public static List<tbKhachHang> Get()
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbKhachHangs.ToList();
        }
        public static tbKhachHang Get(int CustomerId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbKhachHangs.Single(x => x.Id == CustomerId);
        }
        public static bool Put(tbKhachHang Customer)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.Entry(Customer).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(tbKhachHang Customer)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbKhachHangs.Add(Customer);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(int CustomerId)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                tbKhachHang Customer = db.tbKhachHangs.Single(x => x.Id == CustomerId);
                db.tbKhachHangs.Remove(Customer);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}