﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class RoomDao
    {
        public static List<tbPhong> Get()
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbPhongs.ToList();
        }        
        public static List<tbPhong> Get(bool status)
        {
            dbQLKhachSan db = new dbQLKhachSan();            
            return (from tb in db.tbPhongs where tb.Status==status select tb).ToList();
        }
        public static List<tbPhong> Get(DateTime ComeDay,DateTime ReturnDay)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            List<tbPhong> recycleList = Get();
            List<tbPhong> resultList = new List<tbPhong>();
            foreach(var item in recycleList)
            {
                bool receive = true;
                foreach(var borrow in item.tbPhieuDatPhongs)
                {
                    if (borrow.ComeDay < ComeDay && borrow.ReturnDay > ReturnDay)
                    {
                        receive = false;
                        break;
                    }
                    if(borrow.ComeDay>ComeDay&&borrow.ReturnDay<ReturnDay)
                    {
                        receive = false;
                        break;
                    }
                }
                if (receive)
                    resultList.Add(item);
            }
            return resultList;
        }
        public static tbPhong Get(int RoomId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbPhongs.Single(x => x.Id==RoomId);
        }
        public static bool Put(tbPhong Room)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.Entry(Room).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(tbPhong Room)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbPhongs.Add(Room);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(int RoomId)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                tbPhong Room = db.tbPhongs.Single(x => x.Id==RoomId);
                db.tbPhongs.Remove(Room);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}