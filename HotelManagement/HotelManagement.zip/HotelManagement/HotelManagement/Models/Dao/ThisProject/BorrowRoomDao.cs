﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class BorrowRoomDao
    {
        public static List<tbPhieuDatPhong> Get()
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbPhieuDatPhongs.ToList();
        }
        public static tbPhieuDatPhong Get(int BorrowRoomId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbPhieuDatPhongs.Single(x => x.Id == BorrowRoomId);
        }
        public static bool Put(tbPhieuDatPhong BorrowRoom)
        {
            try
            {
                BorrowRoom.tbKhachHang = null;
                BorrowRoom.tbNhanVien = null;
                BorrowRoom.tbPhong = null;
                BorrowRoom.tbPhieuDichVus = null;
                BorrowRoom.tbHoaDons = null;
                dbQLKhachSan db = new dbQLKhachSan();
                db.Entry(BorrowRoom).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(tbPhieuDatPhong BorrowRoom)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbPhieuDatPhongs.Add(BorrowRoom);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(int BorrowRoomId)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                tbPhieuDatPhong BorrowRoom = db.tbPhieuDatPhongs.Single(x => x.Id == BorrowRoomId);
                db.tbPhieuDatPhongs.Remove(BorrowRoom);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }

        }
        public static void ChangeStatus()
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                var datas = db.tbPhieuDatPhongs;
                foreach(var item in datas)
                {
                    if(item.ReturnDay<DateTime.Now&&item.Status==false)
                    {
                        item.Status = true;
                    }
                }
                db.SaveChanges();
            }
            catch(Exception e) { }
        }
    }
}