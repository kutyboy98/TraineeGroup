﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class ServiceDetailDao
    {
        public static List<tbCT_PhieuDichVu> Get()
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbCT_PhieuDichVu.ToList();
        }
        public static tbCT_PhieuDichVu Get(int ServiceDetailId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbCT_PhieuDichVu.Single(x => x.Id == ServiceDetailId);
        }
        public static bool Put(tbCT_PhieuDichVu ServiceDetail)
        {
            try
            {
                ServiceDetail.tbPhieuDichVu = null;
                ServiceDetail.tbDichVu = null;
                dbQLKhachSan db = new dbQLKhachSan();
                db.Entry(ServiceDetail).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(tbCT_PhieuDichVu ServiceDetail)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbCT_PhieuDichVu.Add(ServiceDetail);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(int ServiceDetailId)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                tbCT_PhieuDichVu ServiceDetail = db.tbCT_PhieuDichVu.Single(x => x.Id == ServiceDetailId);
                db.tbCT_PhieuDichVu.Remove(ServiceDetail);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }

        }
    }
}