﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class EmployeeDao
    {
        public static List<tbNhanVien> Get()
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbNhanViens.ToList();
        }
        public static tbNhanVien Get(int EmployeeId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbNhanViens.Single(x => x.Id == EmployeeId);
        }
        public static bool Put(tbNhanVien Employee)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.Entry(Employee).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(tbNhanVien Employee)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbNhanViens.Add(Employee);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(int EmployeeId)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                tbNhanVien Employee = db.tbNhanViens.Single(x => x.Id == EmployeeId);
                db.tbNhanViens.Remove(Employee);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}