﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace HotelManagement.Models.Dao.ThisProject
{
    public class ItemDao
    {
        public static List<tbDichVu> Get()
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbDichVus.ToList();
        }        
        public static tbDichVu Get(int ItemId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            return db.tbDichVus.Single(x => x.Id == ItemId);
        }
        public static bool Put(tbDichVu Item)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.Entry(Item).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Post(tbDichVu Item)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                db.tbDichVus.Add(Item);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool Delete(int ItemId)
        {
            try
            {
                dbQLKhachSan db = new dbQLKhachSan();
                tbDichVu Item = db.tbDichVus.Single(x => x.Id == ItemId);
                db.tbDichVus.Remove(Item);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}