﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.ThisProject;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class BorrowRoomController : Controller
    {
        [HttpGet]
        public ContentResult addBorrowRoom()
        {            
            return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
        }
        [HttpPost]
        public JsonResult addBorrowRoom(tbPhieuDatPhong BorrowRoom)
        {
            BorrowRoom.Status = false;
            if (BorrowRoomDao.Post(BorrowRoom))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm phòng thành công!" });
            }
            return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm phòng thất bại!" });
        }
        //End
        //SHOW: BorrowRooms
        [HttpGet]
        public ContentResult showBorrowRooms()
        {
            BorrowRoomDao.ChangeStatus();
            var BorrowRooms = BorrowRoomDao.Get();
            foreach (var item in BorrowRooms)
            {
                item.tbHoaDons.Clear();
                item.tbKhachHang.tbPhieuDatPhongs.Clear();
                item.tbNhanVien.tbPhieuDatPhongs.Clear();
                item.tbPhieuDichVus.Clear();                
            }
            return Content(JkResponseData.toReturn(BorrowRooms, true, "", ""), "application/json");
        }
        //End
        //View: BorrowRoom
        [HttpGet]
        public ContentResult viewBorrowRoom(int BorrowRoomId)
        {
            var BorrowRoom = BorrowRoomDao.Get(BorrowRoomId);
            BorrowRoom.tbHoaDons.Clear();
            BorrowRoom.tbKhachHang.tbPhieuDatPhongs.Clear();
            BorrowRoom.tbNhanVien.tbPhieuDatPhongs.Clear();
            BorrowRoom.tbPhieuDichVus.Clear();
            return Content(JkResponseData.toReturn(BorrowRoom, true, "", ""), "application/json");
        }
        [HttpGet]
        public ContentResult viewReturnRoom(int BorrowRoomId)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            tbPhieuDatPhong BorrowRoom = db.tbPhieuDatPhongs.Find(BorrowRoomId);
            //Thay đổi phiếu đặt phòng
            if (BorrowRoom.Status!=true)
            {
                BorrowRoom.Status = true;
                BorrowRoom.ReturnDay = DateTime.Now;                
            }
            db.SaveChanges();
            //Tạo bill
            if(BorrowRoom.tbHoaDons.ToList().Count==0)
            {
                tbHoaDon bill = new tbHoaDon();
                bill.CreateDay = DateTime.Now;
                bill.RoomTicket = BorrowRoom.Id;
                bill.TotalPrice = 0;
                foreach (var item in BorrowRoom.tbPhieuDichVus)
                {
                    bill.TotalPrice += item.TotalPrice;
                }
                TimeSpan difference = DateTime.Now - BorrowRoom.ComeDay.GetValueOrDefault();
                bill.TotalPrice += difference.Hours * BorrowRoom.tbPhong.tbLoaiPhong.Price;
                BillDao.Post(bill);
            }            
            return Content(JkResponseData.toReturn(BorrowRoomDao.Get(BorrowRoomId), true, "", ""), "application/json");
        }
        //End
        //Edit: BorrowRoom
        [HttpPost]
        public JsonResult editBorrowRoom(tbPhieuDatPhong BorrowRoom)
        {
            if (BorrowRoomDao.Put(BorrowRoom))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Sửa phiếu đặt phòng " + BorrowRoom.Id +" thành công!"});
            }
            return Json(new JkResponseData { data = "", status = false, error = "", mess = "Sửa phiếu đặt phòng " + BorrowRoom.Id + " thất bại!"});
        }
        //End
        //Delete: BorrowRoom
        [HttpPost]
        public JsonResult deleteBorrowRoom(int BorrowRoomId)
        {
            if (BorrowRoomDao.Delete(BorrowRoomId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}