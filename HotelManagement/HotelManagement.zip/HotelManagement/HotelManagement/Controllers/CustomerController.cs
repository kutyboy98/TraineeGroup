﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.ThisProject;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class CustomerController : Controller
    {
        [HttpGet]
        public ContentResult addCustomer()
        {            
            return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
        }
        [HttpPost]
        public JsonResult addCustomer(tbKhachHang Customer)
        {            
            if (CustomerDao.Post(Customer))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm khách hàng thành công!" });
            }
            return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm khách hàng thất bại!" });
        }
        //End
        //SHOW: Customers
        [HttpGet]
        public ContentResult showCustomers()
        {
            var Customers = CustomerDao.Get();
            foreach (var item in Customers)
            {
                item.tbPhieuDatPhongs.Clear();
            }
            return Content(JkResponseData.toReturn(Customers, true, "", ""), "application/json");
        }
        //End
        //View: Customer
        [HttpGet]
        public ContentResult viewCustomer(int CustomerId)
        {
            var Customer = CustomerDao.Get(CustomerId);
            Customer.tbPhieuDatPhongs.Clear();
            return Content(JkResponseData.toReturn(Customer, true, "", ""), "application/json");
        }
        //End
        //Edit: Customer
        [HttpPost]
        public JsonResult editCustomer(tbKhachHang Customer)
        {
            if (CustomerDao.Put(Customer))
            {
                    return Json(new JkResponseData { data = "", status = true, error = "", mess = "Sửa thông tin khách hàng " + Customer.Name + " thành công!" });
            }
            return Json(new JkResponseData { data = "", status = false, error = "", mess = "Sửa thông tin khách hàng " + Customer.Name + " thất bại!" });
        }
        //End
        //Delete: Customer
        [HttpPost]
        public JsonResult deleteCustomer(int CustomerId)
        {
            if (CustomerDao.Delete(CustomerId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}