﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.ThisProject;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace HotelManagement.Controllers
{
    public class RoomController : Controller
    {
        [HttpGet]
        public ContentResult addRoom()
        {
            var RoomCategory = RoomCategoryDao.Get();
            return Content(JkResponseData.toReturn(RoomCategory, true, "", ""), "application/json");
        }
        [HttpPost]
        public JsonResult addRoom(tbPhong Room)
        {
            Room.Status = true;
            if (RoomDao.Post(Room))
            {                
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm phòng thành công!" });
            }
            return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm phòng thất bại!" });
        }
        //End
        //SHOW: Rooms
        [HttpGet]
        public ContentResult showRooms()
        {
            var Rooms = RoomDao.Get();            
            foreach(var item in Rooms)
            {
                item.tbLoaiPhong.tbPhongs.Clear();                
                item.tbPhieuDatPhongs.Clear();
            }
            return Content(JkResponseData.toReturn(Rooms, true, "", ""), "application/json");
        }
        [HttpGet]
        public ContentResult showRoomsStatus(bool status)
        {
            var Rooms = RoomDao.Get(status);
            foreach (var item in Rooms)
            {
                item.tbLoaiPhong.tbPhongs.Clear();
                item.tbPhieuDatPhongs.Clear();
            }
            return Content(JkResponseData.toReturn(Rooms, true, "", ""), "application/json");
        }
        [HttpGet]
        public ContentResult showRoomsDate(DateTime ComeDay,DateTime ReturnDay)
        {
            var Rooms = RoomDao.Get(ComeDay,ReturnDay);
            foreach (var item in Rooms)
            {
                item.tbLoaiPhong.tbPhongs.Clear();
                item.tbPhieuDatPhongs.Clear();
            }
            return Content(JkResponseData.toReturn(Rooms, true, "", ""), "application/json");
        }
        //End
        //View: Room
        [HttpGet]
        public ContentResult viewRoom(int RoomId)
        {
            var Room = RoomDao.Get(RoomId);
            Room.tbLoaiPhong.tbPhongs.Clear();
            Room.tbPhieuDatPhongs.Clear();
            return Content(JkResponseData.toReturn(Room, true, "", ""), "application/json");
        }
        //End
        //Edit: Room
        [HttpPost]
        public JsonResult editRoom(tbPhong Room)
        {
            if (RoomDao.Put(Room))
            {
                    return Json(new JkResponseData { data = "", status = true, error = "", mess = "Sửa phòng " + Room.Number + " Tầng " + Room.Floor + " thành công!" });
            }
            return Json(new JkResponseData { data = "", status = false, error = "", mess = "Sửa phòng " + Room.Number + " Tầng " + Room.Floor + " thất bại!" });
        }
        //End
        //Delete: Room
        [HttpPost]
        public JsonResult deleteRoom(int RoomId)
        {
            if (RoomDao.Delete(RoomId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}