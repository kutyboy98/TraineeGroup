﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.ThisProject;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class RoomCategoryController : Controller
    {
        [HttpGet]
        public ContentResult showRoomCategorys()
        {
            var RoomCategorys = RoomCategoryDao.Get();
            foreach (var item in RoomCategorys)
            {
                item.tbPhongs.Clear();
            }
            return Content(JkResponseData.toReturn(RoomCategorys, true, "", ""), "application/json");
        }
    }
}