﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using HotelManagement.Models.Dao.ThisProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public ContentResult viewAccount()
        {          
            if(Session["account"]==null)
            {
                
            }
            tbTaiKhoan account = (tbTaiKhoan)Session["account"];          
            return Content(JkResponseData.toReturn(account,true,"",""), "application/json");
        }
        [HttpPost]
        public JsonResult editAccount(tbTaiKhoan account)
        {
            if (Session["account"] == null)
            {
                
            }
            tbTaiKhoan currentAccount = (tbTaiKhoan)Session["account"];
            account.accountId = currentAccount.accountId;
            if (AccountDao.Put(account))
            {
                Session["account"] = account;
                return Json(JkResponseData.toReturn("", true, "", "Sửa thông tin thành công"));                
            }                
            return Json(JkResponseData.toReturn("", false, "", "Sửa thông tin thất bại"));
        }
        [HttpPost]
        public JsonResult changePass(string NewPass, string OldPass)
        {
            tbTaiKhoan acc = (tbTaiKhoan)Session["account"];            
            if (MD5HashCode.getHashCode(OldPass.Trim()).ToLower().Equals(acc.passWord.Trim()) )
            {
                acc.passWord = MD5HashCode.getHashCode(NewPass.Trim()).ToLower();
                Session["account"] = acc;
                try
                {
                    AccountDao.Put(acc);
                    return Json(JkResponseData.toReturn("", true, "", "Thay đổi mật khẩu thành công!"));
                }
                catch
                {
                    return Json(JkResponseData.toReturn("", false, "", "Thay đổi mật khẩu thất bại!"));
                }
            }
            return Json(JkResponseData.toReturn("", false, "", "Mật khẩu cũ không chính xác!"));
        }
        [HttpPost]
        public JsonResult checkOldPass(string OldPass)
        {
            tbTaiKhoan acc = (tbTaiKhoan)Session["account"];
            if (MD5HashCode.getHashCode(OldPass.Trim()).ToLower().Equals(acc.passWord.Trim()))
            {
                return Json(JkResponseData.toReturn("", true, "", "Mật khẩu cũ chính xác!"));
            }
            return Json(JkResponseData.toReturn("", false, "", "Mật khẩu cũ không chính xác!"));
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string userName,string passWord)
        {
            dbQLKhachSan db = new dbQLKhachSan();
            var tableAccount = from tbTaiKhoan in db.tbTaiKhoans select tbTaiKhoan;
            foreach (var acc in tableAccount)
            {
                try
                {
                    if (MD5HashCode.getHashCode(passWord.Trim()).ToLower().Equals(acc.passWord.Trim()) && acc.userName.Trim().Equals(userName.Trim()))
                    {
                        Session["account"] = acc;
                        return RedirectToAction("Index", "Home");
                    }
                }
                catch
                {
                    continue;
                }

            }            
            return RedirectToAction("Login");
        }
    }
}