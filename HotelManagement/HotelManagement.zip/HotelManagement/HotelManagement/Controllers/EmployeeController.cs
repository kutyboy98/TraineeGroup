﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.ThisProject;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class EmployeeController : Controller
    {
        [HttpGet]
        public ContentResult addEmployee()
        {
            var CityList = AddressDao.getCityList();
            return Content(JkResponseData.toReturn(CityList, true, "", ""), "application/json");
        }
        [HttpPost]
        public JsonResult addEmployee(tbNhanVien Employee)
        {
            if (EmployeeDao.Post(Employee))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm nhân viên thành công!" });
            }
            return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm nhân viên thất bại!" });
        }
        //End
        //SHOW: Employees
        [HttpGet]
        public ContentResult showEmployees()
        {
            var Employees = EmployeeDao.Get();
            foreach (var item in Employees)
            {
                item.tbHoaDons.Clear();
                item.tbPhieuDatPhongs.Clear();
            }
            return Content(JkResponseData.toReturn(Employees, true, "", ""), "application/json");
        }
        //End
        //View: Employee
        [HttpGet]
        public ContentResult viewEmployee(int EmployeeId)
        {
            var Employee = EmployeeDao.Get(EmployeeId);
            Employee.tbPhieuDatPhongs.Clear();
            Employee.tbHoaDons.Clear();
            return Content(JkResponseData.toReturn(Employee, true, "", ""), "application/json");
        }
        //End
        //Edit: Employee
        [HttpPost]
        public JsonResult editEmployee(tbNhanVien Employee)
        {
            if (EmployeeDao.Put(Employee))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Sửa thông tin nhân viên " + Employee.Name + " thành công!" });
            }
            return Json(new JkResponseData { data = "", status = false, error = "", mess = "Sửa thông tin nhân viên " + Employee.Name + " thất bại!" });
        }
        //End
        //Delete: Employee
        [HttpPost]
        public JsonResult deleteEmployee(int EmployeeId)
        {
            if (EmployeeDao.Delete(EmployeeId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}