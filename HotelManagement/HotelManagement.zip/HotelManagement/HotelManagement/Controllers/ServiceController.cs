﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.ThisProject;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class ServiceController : Controller
    {
        [HttpGet]
        public ContentResult addService()
        {
            return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
        }
        [HttpPost]
        public JsonResult addService(tbPhieuDichVu Service)
        {
            Service.CreateDay = DateTime.Now;
            Service.TotalPrice = 0;         
            if (ServiceDao.Post(Service))
            {                
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm dịch vụ thành công!" });
            }
            return Json(new JkResponseData { data = "", status = false, error = "", mess = "Thêm dịch vụ thất bại!" });
        }
        //End
        //SHOW: Services
        [HttpGet]
        public ContentResult showServices()
        {
            var Services = ServiceDao.Get();
            foreach (var item in Services)
            {
                
            }
            return Content(JkResponseData.toReturn(Services, true, "", ""), "application/json");
        }
        //End
        //View: Service
        [HttpGet]
        public ContentResult viewService(int ServiceId)
        {
            var Service = ServiceDao.Get(ServiceId);
            Service.tbPhieuDatPhong.tbPhieuDichVus.Clear();
            Service.tbPhieuDatPhong.tbHoaDons.Clear();
            Service.tbPhieuDatPhong.tbNhanVien = new tbNhanVien();
            Service.tbPhieuDatPhong.tbKhachHang = new tbKhachHang();            
            Service.tbPhieuDatPhong.tbPhong = new tbPhong();
            foreach (var item in Service.tbCT_PhieuDichVu)
            {
                item.tbDichVu.tbCT_PhieuDichVu.Clear();
                item.tbPhieuDichVu = new tbPhieuDichVu();
            }
            return Content(JkResponseData.toReturn(Service, true, "", ""), "application/json");
        }
        //End
        //Edit: Service
        [HttpPost]
        public JsonResult editService(tbPhieuDichVu Service)
        {
            Service.TotalPrice = 0;
            foreach(var item in Service.tbCT_PhieuDichVu)
            {
                Service.TotalPrice += item.Price.GetValueOrDefault() * item.Amount.GetValueOrDefault();
                item.tbDichVu = null;
                if(item.Id==0)
                {
                    ServiceDetailDao.Post(item);
                }
                else
                {
                    ServiceDetailDao.Put(item);
                }
            }
            if (ServiceDao.Put(Service))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Sửa phiếu đặt phòng " + Service.Id + " thành công!" });
            }
            return Json(new JkResponseData { data = "", status = false, error = "", mess = "Sửa phiếu đặt phòng " + Service.Id + " thất bại!" });
        }
        //End
        //Delete: Service
        [HttpPost]
        public JsonResult deleteService(int ServiceId)
        {
            if (ServiceDao.Delete(ServiceId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}