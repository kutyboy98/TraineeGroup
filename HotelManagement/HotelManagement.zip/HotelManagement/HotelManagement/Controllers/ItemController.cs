﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.ThisProject;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class ItemController : Controller
    {
        [HttpGet]
        public ContentResult addItem()
        {
            return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
        }
        [HttpPost]
        public JsonResult addItem(tbDichVu Item)
        {
            if (ItemDao.Post(Item))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm phòng thành công!" });
            }
            return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm phòng thất bại!" });
        }
        //End
        //SHOW: Items
        [HttpGet]
        public ContentResult showItems()
        {
            var Items = ItemDao.Get();
            foreach (var item in Items)
            {
                item.tbCT_PhieuDichVu.Clear();
            }
            return Content(JkResponseData.toReturn(Items, true, "", ""), "application/json");
        }
        //End
        //View: Item
        [HttpGet]
        public ContentResult viewItem(int ItemId)
        {
            var Item = ItemDao.Get(ItemId);
            Item.tbCT_PhieuDichVu.Clear();
            return Content(JkResponseData.toReturn(Item, true, "", ""), "application/json");
        }
        //End
        //Edit: Item
        [HttpPost]
        public JsonResult editItem(tbDichVu Item)
        {
            if (ItemDao.Put(Item))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Sửa phiếu đặt phòng " + Item.Id + " thành công!" });
            }
            return Json(new JkResponseData { data = "", status = false, error = "", mess = "Sửa phiếu đặt phòng " + Item.Id + " thất bại!" });
        }
        //End
        //Delete: Item
        [HttpPost]
        public JsonResult deleteItem(int ItemId)
        {
            if (ItemDao.Delete(ItemId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}