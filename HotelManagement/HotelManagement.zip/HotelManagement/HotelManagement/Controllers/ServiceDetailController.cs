﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.ThisProject;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class ServiceDetailController : Controller
    {
        [HttpGet]
        public ContentResult addServiceDetail()
        {
            return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
        }
        [HttpPost]
        public JsonResult addServiceDetail(tbCT_PhieuDichVu ServiceDetail)
        {            
            if (ServiceDetailDao.Post(ServiceDetail))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm phòng thành công!" });
            }
            return Json(new JkResponseData { data = "", status = true, error = "", mess = "Thêm phòng thất bại!" });
        }
        //End
        //SHOW: ServiceDetails
        [HttpGet]
        public ContentResult showServiceDetails()
        {
            var ServiceDetails = ServiceDetailDao.Get();
            foreach (var item in ServiceDetails)
            {

            }
            return Content(JkResponseData.toReturn(ServiceDetails, true, "", ""), "application/json");
        }
        //End
        //View: ServiceDetail
        [HttpGet]
        public ContentResult viewServiceDetail(int ServiceDetailId)
        {
            var ServiceDetail = ServiceDetailDao.Get(ServiceDetailId);
            return Content(JkResponseData.toReturn(ServiceDetail, true, "", ""), "application/json");
        }
        //End
        //Edit: ServiceDetail
        [HttpPost]
        public JsonResult editServiceDetail(tbCT_PhieuDichVu ServiceDetail)
        {
            if (ServiceDetailDao.Put(ServiceDetail))
            {
                return Json(new JkResponseData { data = "", status = true, error = "", mess = "Sửa phiếu đặt phòng " + ServiceDetail.Id + " thành công!" });
            }
            return Json(new JkResponseData { data = "", status = false, error = "", mess = "Sửa phiếu đặt phòng " + ServiceDetail.Id + " thất bại!" });
        }
        //End
        //Delete: ServiceDetail
        [HttpPost]
        public JsonResult deleteServiceDetail(int ServiceDetailId)
        {
            if (ServiceDetailDao.Delete(ServiceDetailId))
            {
                return Json(true);
            }
            return Json(false);
        }
    }
}