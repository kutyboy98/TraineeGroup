﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (Session["account"] == null)
                return RedirectToAction("Login", "Home");
            ViewBag.account = (tbTaiKhoan)Session["account"];
            dbQLKhachSan db = new dbQLKhachSan();
            ViewBag.menu = (from lst in db.Menus where lst.parentId == null select lst).ToList();
            return View();
        }
        
    }
}