﻿using HotelManagement.Models;
using HotelManagement.Models.Dao.AnyProject;
using HotelManagement.Models.Dao.AnyProject.Jker;
using HotelManagement.Models.Dao.ThisProject;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WarehouseManagerment.Controllers
{
    public class AddressController : Controller
    {
        // GET: Address
        [HttpGet]
        public ContentResult getCityList()
        {
            var data = AddressDao.getCityList();
            return Content(JkResponseData.toReturn(data, true, "", ""), "application/json");
        }
        [HttpGet]
        public ContentResult getDistrictList(string cityId)
        {
            try
            {
                var data = AddressDao.getDistrictList(Convert.ToInt32(cityId));
                return Content(JkResponseData.toReturn(data, true, "", ""), "application/json");
            }
            catch
            {
                return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
            }
        }
        [HttpGet]
        public ContentResult getTownList(string districtId)
        {
            try
            {
                var data = AddressDao.getTownList(Convert.ToInt32(districtId));
                return Content(JkResponseData.toReturn(data, true, "", ""), "application/json");
            }
            catch
            {
                return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
            }
        }
        [HttpGet]
        public ContentResult getStrAddress(string townId)
        {
            try
            {
                var data = AddressDao.getStrAddress(Convert.ToInt32(townId));
                return Content(JkResponseData.toReturn(data, true, "", ""), "application/json");
            }
            catch
            {
                return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
            }
        }
        [HttpGet]
        public ContentResult getAddress(string townId)
        {
            try
            {
                var data = AddressDao.getAddress(Convert.ToInt32(townId));
                return Content(JkResponseData.toReturn(data, true, "", ""), "application/json");
            }
            catch
            {
                return Content(JkResponseData.toReturn("", true, "", ""), "application/json");
            }
        }
    }
}